from fastapi import FastAPI
from pydantic import BaseModel
import random

app = FastAPI()

class SOSIn(BaseModel):
    lat: float | None = None
    lng: float | None = None
    msg: str | None = None

@app.post('/predict')
def predict(s: SOSIn):
    score = 0.1
    if not s.lat or not s.lng: score += 0.5
    if s.msg:
        score += min(len(s.msg) / 100.0, 0.3)
    score = min(round(score + random.uniform(0,0.1),2), 1.0)
    return {"risk_score": score}
