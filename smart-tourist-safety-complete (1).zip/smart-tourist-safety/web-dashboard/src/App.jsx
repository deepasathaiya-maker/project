import React, {useEffect, useState} from 'react'

export default function App(){
  const [sos, setSos] = useState([]);
  useEffect(()=> {
    fetch('http://localhost:3000/api/sos', { headers:{ Authorization: 'Bearer demo' }})
      .then(r=>r.json()).then(setSos).catch(()=>setSos([]));
  },[]);
  return (
    <div style={{padding:20}}>
      <h2>Dispatcher Dashboard (demo)</h2>
      <table border="1" cellPadding="6">
        <thead><tr><th>ID</th><th>Email</th><th>lat</th><th>lng</th><th>msg</th></tr></thead>
        <tbody>
          {sos.map(s=>(
            <tr key={s._id}><td>{s._id}</td><td>{s.userEmail}</td><td>{s.lat}</td><td>{s.lng}</td><td>{s.msg}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
