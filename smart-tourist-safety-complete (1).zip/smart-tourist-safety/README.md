# Smart Tourist Safety (demo)

This is a demo full-stack scaffold including:
- backend (Node.js + Express + JWT + WebSocket signaling)
- AI microservice (FastAPI)
- frontend (static tourist UI)
- web-dashboard (React/Vite)
- minimal Fabric chaincode stub
- docker-compose to run backend, mongo, ai-service, dashboard

Quick start:
1. Install Docker and Docker Compose
2. From project root run:
   docker-compose up --build
3. Open:
   - Backend / frontend: http://localhost:3000
   - Dashboard: http://localhost:5173

Demo credentials seeded:
- admin@sts.com / Admin@123
- t1@sts.com / tourist1
