let token = null;
let localId = 'c-' + Math.random().toString(36).slice(2,8);
let ws;
let pc;
let dc;
const logEl = document.getElementById('log');
function log(s){ logEl.textContent += s + "\n"; logEl.scrollTop = logEl.scrollHeight; }

document.getElementById('btnDemo').onclick = async () => {
  // demo admin
  const r = await fetch('/api/auth/login', {method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({email:'admin@sts.com', password:'Admin@123'})});
  const j = await r.json();
  token = j.token;
  log('Demo login admin: ' + JSON.stringify(j.user));
  startWs();
};

document.getElementById('btnLogin').onclick = async () => {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  try{
    const r = await fetch('/api/auth/login', {method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({email,password})});
    const j = await r.json();
    if (j.token) token = j.token, log('Logged in: ' + JSON.stringify(j.user)), startWs();
    else log('login failed ' + JSON.stringify(j));
  }catch(e){ log('err '+e.message) }
};

function startWs(){
  if(ws) return;
  ws = new WebSocket((location.protocol==='https:'?'wss://':'ws://') + location.host);
  ws.onopen = ()=> { log('WS open'); ws.send(JSON.stringify({type:'hello', id: localId})) };
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    log('WS message: ' + JSON.stringify(m));
    if(m.offer) handleOffer(m);
    if(m.answer) handleAnswer(m.answer);
    if(m.candidate && pc) pc.addIceCandidate(m.candidate).catch(console.error);
  };
}

document.getElementById('btnStart').onclick = async () => {
  if(!ws) startWs();
  createPeer();
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  ws.send(JSON.stringify({ offer, from: localId }));
  log('sent offer');
};

function createPeer(){
  pc = new RTCPeerConnection({ iceServers:[{urls:'stun:stun.l.google.com:19302'}] });
  dc = pc.createDataChannel('sos');
  dc.onopen = ()=> log('datachannel open');
  dc.onmessage = e => log('p2p msg: ' + e.data);
  pc.onicecandidate = ev => { if(ev.candidate) ws.send(JSON.stringify({ candidate: ev.candidate, from: localId })); };
  pc.ondatachannel = ev => ev.channel.onmessage = (e)=> log('remote: '+e.data);
}

async function handleOffer(msg){
  if(!pc) createPeer();
  await pc.setRemoteDescription(msg.offer);
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  ws.send(JSON.stringify({ answer, from: localId, to: msg.from }));
  log('answered offer');
}

async function handleAnswer(answer){
  if(!pc) return;
  await pc.setRemoteDescription(answer);
  log('set remote desc (answer)');
}

document.getElementById('btnSOS').onclick = async () => {
  const payload = { lat:12.9716, lng:77.5946, msg:'Demo SOS' };
  if(!token){
    log('No token, broadcasting via WS');
    if(ws && ws.readyState===WebSocket.OPEN) ws.send(JSON.stringify({ type:'sos-broadcast', sos: payload }));
    return;
  }
  const r = await fetch('/api/sos', { method:'POST', headers:{'content-type':'application/json', Authorization:'Bearer '+token}, body: JSON.stringify(payload) });
  const j = await r.json();
  log('SOS posted: ' + JSON.stringify(j));
  if(dc && dc.readyState==='open') dc.send(JSON.stringify({ type:'sos', payload }));
};

document.getElementById('btnGet').onclick = async () => {
  if(!token) { log('no token'); return; }
  const r = await fetch('/api/sos', { headers:{ Authorization:'Bearer '+token }});
  const j = await r.json();
  log('SOS list: ' + JSON.stringify(j));
};
