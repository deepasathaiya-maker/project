const path = require('path');
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const bodyParser = require('body-parser');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/sts';
const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:5000';
const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';
const PORT = process.env.PORT || 3000;

let db;
async function initDb(){
  const client = new MongoClient(MONGO_URI);
  await client.connect();
  db = client.db();
  // seed demo data if empty
  const users = db.collection('users');
  const count = await users.countDocuments();
  if(count === 0){
    const adminPass = await bcrypt.hash('Admin@123', 8);
    const t1 = await bcrypt.hash('tourist1', 8);
    await users.insertMany([
      { email: 'admin@sts.com', password: adminPass, role: 'dispatcher', name: 'Admin' },
      { email: 't1@sts.com', password: t1, role: 'tourist', name: 'Tourist One' }
    ]);
    const sos = db.collection('sos');
    await sos.insertOne({ userEmail: 't1@sts.com', lat:12.9716, lng:77.5946, msg:'Test SOS', status:'active', ts: new Date() });
    console.log('seeded demo users and sos');
  }
}
initDb().catch(err=>console.error(err));

function generateToken(user){
  return jwt.sign({ sub: user._id.toString(), role: user.role, email: user.email }, JWT_SECRET, { expiresIn: '12h' });
}

function authMiddleware(req, res, next){
  const h = req.headers.authorization;
  if(!h) return res.status(401).json({error:'no auth'});
  const token = h.replace('Bearer ','');
  try{
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch(e){ res.status(401).json({error:'invalid token'}) }
}

// Auth routes
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const users = db.collection('users');
  const user = await users.findOne({ email });
  if(!user) return res.status(401).json({error:'invalid'});
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(401).json({error:'invalid'});
  const token = generateToken(user);
  res.json({ token, user: { email: user.email, role: user.role, name: user.name } });
});

app.post('/api/auth/register', async (req, res) => {
  const { email, password, name, role='tourist' } = req.body;
  const users = db.collection('users');
  const exist = await users.findOne({ email });
  if(exist) return res.status(400).json({ error:'exists' });
  const hash = await bcrypt.hash(password, 8);
  const r = await users.insertOne({ email, password: hash, name, role });
  res.json({ id: r.insertedId });
});

// SOS endpoints
app.post('/api/sos', authMiddleware, async (req, res) => {
  const { lat, lng, msg } = req.body;
  const sos = db.collection('sos');
  const doc = { userId: req.user.sub, userEmail: req.user.email, lat, lng, msg, status:'active', ts: new Date() };
  const r = await sos.insertOne(doc);
  // notify via websocket server
  broadcast({ type:'sos-created', sos: { id: r.insertedId, ...doc } });
  res.json({ id: r.insertedId });
});

app.get('/api/sos', authMiddleware, async (req, res) => {
  const sos = db.collection('sos');
  const rows = await sos.find({}).sort({ts:-1}).limit(200).toArray();
  res.json(rows);
});

// Tourist profile
app.get('/api/me', authMiddleware, async (req,res) => {
  const users = db.collection('users');
  const user = await users.findOne({ _id: new ObjectId(req.user.sub) }, { projection:{password:0} });
  res.json(user);
});

app.put('/api/me', authMiddleware, async (req,res) => {
  const users = db.collection('users');
  const { name } = req.body;
  await users.updateOne({ _id: new ObjectId(req.user.sub) }, { $set: { name }});
  res.json({ ok:true });
});

// Serve frontend
app.get('/', (req,res) => {
  res.sendFile(path.join(__dirname,'..','public','index.html'));
});

// WebSocket signaling & broadcasts
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

function broadcast(obj){
  const raw = JSON.stringify(obj);
  wss.clients.forEach(c => { if(c.readyState === WebSocket.OPEN) c.send(raw); });
}

wss.on('connection', ws => {
  console.log('ws connected');
  ws.on('message', raw => {
    try {
      const msg = JSON.parse(raw);
      // forward to others
      wss.clients.forEach(c => {
        if(c !== ws && c.readyState === WebSocket.OPEN) c.send(JSON.stringify(msg));
      });
    } catch(e){}
  });
  ws.on('close', ()=>{ console.log('ws closed') });
});

server.listen(PORT, ()=> console.log('Backend listening on', PORT));
